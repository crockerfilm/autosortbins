/* AutoSortBins v2.11.0 — UXP panel
   Requires Premiere Pro 22.0+ (2022+).

   Architecture notes:
   - No evalScript bridge. The premierepro module is required directly.
   - All project operations are async/await.
   - executeTransaction() wraps moves in a single undoable operation.
   - Bins are pre-created before the transaction so we hold live references.
   - Backup copies the .prproj via the UXP localFileSystem API before any sort.
*/
(function () {
    "use strict";

    // ── UXP / Premiere API ───────────────────────────────────────────────────
    var ppro = null;
    var uxpStorage = null;
    try { ppro = require("premierepro"); } catch (e) {}
    try { uxpStorage = require("uxp").storage.localFileSystem; } catch (e) {}

    // ProjectItem type constants (mirror CEP values; UXP uses same integers)
    var TYPE_BIN  = 2;
    var TYPE_ROOT = 3;

    // ── State ────────────────────────────────────────────────────────────────
    var STORAGE_KEY = "autosortbins.config.v4.uxp";
    var lastPreviewPlan      = null;   // { moves, categories }
    var lastEmptyPreviewPlan = null;   // [{ item, name, depth }]

    // ── DOM helpers ──────────────────────────────────────────────────────────
    function $(id) { return document.getElementById(id); }
    function esc(s) {
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    }
    function stamp() {
        var d = new Date(), p = function(n){ return (n<10?"0":"")+n; };
        return p(d.getHours())+":"+p(d.getMinutes())+":"+p(d.getSeconds());
    }
    function appendLog(html) {
        var log = $("log");
        log.insertAdjacentHTML("beforeend", html + "\n");
        log.scrollTop = log.scrollHeight;
    }
    function appendCleanupLog(html) {
        var log = $("logCleanup");
        if (!log) { appendLog(html); return; }
        log.insertAdjacentHTML("beforeend", html + "\n");
        log.scrollTop = log.scrollHeight;
    }
    function setStatus(text, kind) {
        var el = $("status");
        el.textContent = text;
        el.className = "status status--" + (kind || "idle");
    }
    function setSortEnabled(on) {
        $("btnSort").disabled = !on;
        $("btnSort").title = on ? "Sort exactly what Preview showed" : "Run Preview first";
    }
    function setEmptyEnabled(on) {
        var btn = $("btnRemoveEmpty");
        if (btn) btn.disabled = !on;
    }
    function logError(msg) {
        appendLog('<span class="fail">⚠ ' + esc(msg) + ' <span class="muted">· ' + stamp() + '</span></span>');
        setStatus("Error", "error");
        setSortEnabled(false);
    }

    // ── Default rules ────────────────────────────────────────────────────────
    function defaultRules() {
        return [
            { bin: "01 Sequences",             special: "sequence", exts: "", keywords: "" },
            { bin: "02 Footage",               exts: "mp4,mov,mxf,avi,mkv,m4v,mpg,mpeg,webm,r3d,braw,wmv,mts,m2ts,m2v,dv,dpx,ari,arx,crm,insv,cine", keywords: "" },
            { bin: "03 Graphics & Stills",     exts: "png,jpg,jpeg,gif,tif,tiff,psd,ai,eps,bmp,tga,exr,svg,heic,webp,raw,dng,cr2,cr3,nef,arw,orf,mogrt", keywords: "" },
            { bin: "04 SFX",                   exts: "wav,mp3,aif,aiff,m4a,aac,flac,ogg,wma", keywords: "sfx,foley,whoosh,impact,riser,swoosh,boom,hit,transition,ui_,click,glitch" },
            { bin: "05 Music",                 exts: "wav,mp3,aif,aiff,m4a,aac,flac,ogg,wma", keywords: "music,bgm,track,song,score,theme,loop,beat,instrumental,stem" },
            { bin: "06 Audio (other)",         exts: "wav,mp3,aif,aiff,m4a,aac,flac,ogg,wma", keywords: "" },
            { bin: "07 Linked AE",             exts: "aep,aepx,aet,aetx", keywords: "" },
            { bin: "08 Project & Transfer",    exts: "prproj,pproj,plproj,sesx,aaf,omf,xml,fcpxml,edl", keywords: "" },
            { bin: "09 Captions & Subtitles",  exts: "srt,vtt,scc,mcc,stl,dfxp,ttml", keywords: "" },
            { bin: "10 LUTs & Presets",        exts: "cube,look,lut,epr,prfpset,xmp", keywords: "" },
            { bin: "11 Docs & References",     exts: "pdf,txt,rtf,doc,docx,csv,xls,xlsx,ppt,pptx", keywords: "" },
            { bin: "12 Fonts",                 exts: "otf,ttf,woff,woff2", keywords: "" },
            { bin: "99 Misc",                  special: "catchall", exts: "", keywords: "" }
        ];
    }

    // ── Rules helpers (identical logic to CEP version) ───────────────────────
    function splitCsv(s) {
        if (!s) return [];
        return s.split(/[,\s]+/).map(function(x){ return x.replace(/^\./,"").trim().toLowerCase(); }).filter(Boolean);
    }
    function cleanBinName(name) {
        return String(name||"").replace(/[\r\n|]/g," ").replace(/\s+/g," ").trim().substring(0,80);
    }
    function mergeCsv(a, b) {
        var items = splitCsv(a||""), seen = {};
        items.forEach(function(x){ seen[x]=true; });
        splitCsv(b||"").forEach(function(x){ if(!seen[x]){items.push(x);seen[x]=true;} });
        return items.join(",");
    }
    function mergeMissingDefaultRules(rules) {
        if (!rules || !rules.length) return defaultRules();
        var out = rules.slice(0), existing = {};
        out.forEach(function(r){ existing[String((r&&r.bin)||"").toLowerCase()] = r; });
        var defs = defaultRules(), catchIndex = out.length;
        for (var i=0;i<out.length;i++) { if(out[i]&&out[i].special==="catchall"){catchIndex=i;break;} }
        defs.forEach(function(d){
            var key = String(d.bin||"").toLowerCase();
            if (!key) return;
            if (existing[key]) {
                if (!d.special && !existing[key].special) {
                    existing[key].exts     = mergeCsv(existing[key].exts||"",     d.exts||"");
                    existing[key].keywords = mergeCsv(existing[key].keywords||"", d.keywords||"");
                }
                return;
            }
            if (d.special === "sequence" || d.special === "catchall") return;
            out.splice(catchIndex, 0, d); catchIndex++; existing[key] = d;
        });
        return out;
    }

    // ── Persist / load state ─────────────────────────────────────────────────
    function loadState() {
        try {
            var raw = window.localStorage.getItem(STORAGE_KEY);
            if (raw) {
                var obj = JSON.parse(raw);
                return {
                    rules:         mergeMissingDefaultRules((obj&&obj.rules&&obj.rules.length)?obj.rules:defaultRules()),
                    keepSubfolders: !!(obj&&obj.keepSubfolders)
                };
            }
        } catch(e) {}
        return { rules: defaultRules(), keepSubfolders: false };
    }
    function readRulesFromUI() {
        var rows = $("ruleList").querySelectorAll(".rule"), out = [];
        rows.forEach(function(row){
            var special = row.dataset.special || "";
            var bin = cleanBinName(row.querySelector(".rule-bin").value);
            if (!bin) return;
            var r = { bin: bin };
            if (special) { r.special = special; }
            else {
                r.exts     = (row.querySelector(".rule-exts").value||"").trim();
                r.keywords = (row.querySelector(".rule-kws").value||"").trim();
            }
            out.push(r);
        });
        return out;
    }
    function saveState() {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
                rules:         readRulesFromUI(),
                keepSubfolders: !!($("keepSubfolders")&&$("keepSubfolders").checked)
            }));
        } catch(e) {}
    }
    function buildCategories() {
        return readRulesFromUI().map(function(r){
            var cat = { bin: r.bin };
            if (r.special==="sequence") { cat.match="sequence"; return cat; }
            if (r.special==="catchall") { cat.catchall=true; return cat; }
            cat.exts     = splitCsv(r.exts);
            cat.keywords = splitCsv(r.keywords);
            return cat;
        });
    }

    // ── UI: rule rows ────────────────────────────────────────────────────────
    function inp(type, val, ph) {
        var el = document.createElement("input");
        el.type = type; el.value = val||"";
        if (ph) el.placeholder = ph;
        return el;
    }
    function ruleRow(r) {
        var row = document.createElement("div");
        row.className = "rule";
        var special = r.special || "";
        var bin = inp("text", r.bin||"", "bin name"); bin.className = "rule-bin";
        var exts, kws;
        if (special==="sequence"||special==="catchall") {
            exts = inp("text", special==="sequence"?"(all sequences & nests)":"(everything else)", "");
            exts.className = "special-tag"; exts.disabled = true;
            kws = inp("text","—",""); kws.disabled = true;
        } else {
            exts = inp("text", r.exts||"", "mp4, mov, ..."); exts.className = "rule-exts";
            kws  = inp("text", r.keywords||"", "optional");  kws.className  = "rule-kws";
        }
        var del = document.createElement("button");
        del.className = "del"; del.textContent = "×"; del.title = "Remove rule";
        del.onclick = function(){ row.parentNode.removeChild(row); saveState(); invalidatePreview(); };
        row.dataset.special = special;
        [bin,exts,kws].forEach(function(el){
            el.addEventListener("input", function(){ saveState(); invalidatePreview(); });
        });
        row.appendChild(bin); row.appendChild(exts); row.appendChild(kws); row.appendChild(del);
        return row;
    }
    function renderRules(rules) {
        var list = $("ruleList"); list.innerHTML = "";
        rules.forEach(function(r){ list.appendChild(ruleRow(r)); });
        invalidatePreview();
    }
    function invalidatePreview() {
        lastPreviewPlan = null;
        setSortEnabled(false);
    }
    function invalidateEmptyPreview() {
        lastEmptyPreviewPlan = null;
        setEmptyEnabled(false);
    }

    // ── UXP item children helper ─────────────────────────────────────────────
    // In UXP Premiere Pro, bins/root are "FolderItem" (has getItems()).
    // Items returned from getItems() come back as plain "ProjectItem" (no getItems).
    // To recurse into a bin we must cast: ppro.FolderItem.cast(binItem).getItems()
    function collToArray(coll) {
        if (!coll) return [];
        if (Array.isArray(coll)) return coll;
        var n = typeof coll.numItems === "number" ? coll.numItems
              : typeof coll.length   === "number" ? coll.length : -1;
        if (n >= 0) {
            var out = [];
            for (var i = 0; i < n; i++) { var c = coll[i]; if (c) out.push(c); }
            return out;
        }
        try { var a = []; for (var it of coll) { if (it) a.push(it); } return a; }
        catch(e) { return []; }
    }
    // Saved on first call so bin items can borrow root's getItems via prototype chain
    var _rootGetItemsFn = null;

    async function getChildren(item) {
        if (!item) return [];
        if (Number(item.type) !== TYPE_BIN && Number(item.type) !== TYPE_ROOT) return [];

        // 1. Already a FolderItem (rootItem comes back from getRootItem() fully typed)
        if (typeof item.getItems === "function") {
            var r1 = collToArray(await item.getItems());
            return r1;
        }

        // 2. Official cast: ppro.FolderItem.cast(binProjectItem)
        if (ppro && ppro.FolderItem && typeof ppro.FolderItem.cast === "function") {
            try {
                var folder = ppro.FolderItem.cast(item);
                if (folder && typeof folder.getItems === "function") {
                    return collToArray(await folder.getItems());
                }
            } catch(castErr) {
                appendLog('<span class="muted">dbg cast err on "'+esc(item.name||"?")+'": '+esc(castErr.message||String(castErr))+'</span>');
            }
        } else {
            appendLog('<span class="muted">dbg ppro.FolderItem unavailable ('+typeof(ppro&&ppro.FolderItem)+')</span>');
        }

        // 3. Prototype steal: call root's getItems with bin as receiver
        if (_rootGetItemsFn) {
            try { return collToArray(await _rootGetItemsFn.call(item)); }
            catch(stealErr) {
                appendLog('<span class="muted">dbg steal err on "'+esc(item.name||"?")+'": '+esc(stealErr.message||String(stealErr))+'</span>');
            }
        }

        appendLog('<span class="muted">dbg getChildren: all methods failed for "'+esc(item.name||"?")+'" type='+item.type+'</span>');
        return [];
    }
    // Cast a ProjectItem to FolderItem so we can use it as a move destination
    function asFolderItem(item) {
        if (!item) return item;
        if (typeof item.createMoveItemAction === "function") return item;
        if (ppro && ppro.FolderItem && typeof ppro.FolderItem.cast === "function") {
            return ppro.FolderItem.cast(item);
        }
        return item;
    }

    // ── Project helpers ──────────────────────────────────────────────────────
    function isBin(item) {
        return item && (item.type === TYPE_BIN || item.type === TYPE_ROOT);
    }

    async function getExt(item) {
        // Try media file path first; fall back to item name
        var path = "";
        try {
            if (typeof item.getMediaFilePath === "function") {
                path = (await item.getMediaFilePath()) || "";
            }
        } catch(e) {}
        var src = path || (item.name || "");
        var clean = String(src).split("?")[0].replace(/[\\\/]+$/,"");
        var dot   = clean.lastIndexOf(".");
        var slash = Math.max(clean.lastIndexOf("/"), clean.lastIndexOf("\\"));
        if (dot === -1 || dot < slash) return "";
        return clean.substring(dot+1).toLowerCase();
    }

    async function isSequence(item, project) {
        // UXP: try isSequence() method first
        try {
            if (typeof item.isSequence === "function") return !!(await item.isSequence());
        } catch(e) {}
        // Fallback: items with no media path whose name matches a project sequence
        try {
            var path = "";
            try { path = (typeof item.getMediaFilePath==="function") ? (await item.getMediaFilePath()||"") : ""; } catch(e2) {}
            if (path) return false;
            var seqs = await project.getSequences();
            for (var i=0;i<seqs.length;i++) { if (seqs[i].name===item.name) return true; }
        } catch(e3) {}
        return false;
    }

    async function matchCategory(item, categories, project) {
        var seq = await isSequence(item, project);
        var ext = seq ? "" : await getExt(item);
        var mediaPath = "";
        try { mediaPath = (typeof item.getMediaFilePath==="function") ? (await item.getMediaFilePath()||"") : ""; } catch(e) {}
        var haystack = (String(item.name||"") + " " + mediaPath).toLowerCase();

        for (var c=0; c<categories.length; c++) {
            var cat = categories[c];
            if (cat.match === "sequence") { if (seq) return cat.bin; continue; }
            if (cat.catchall)             { return cat.bin; }

            var extOk = (!cat.exts || !cat.exts.length) ? true : cat.exts.indexOf(ext) !== -1;
            if (!extOk) continue;

            if (cat.keywords && cat.keywords.length) {
                var kwHit = cat.keywords.some(function(kw){ return kw && haystack.indexOf(kw)!==-1; });
                if (kwHit) return cat.bin;
                continue;
            }
            return cat.bin;
        }
        return null;
    }

    async function findChildBin(parentItem, name) {
        var lower = name.toLowerCase();
        var children = await getChildren(parentItem);
        for (var i=0;i<children.length;i++) {
            var ch = children[i];
            if (isBin(ch) && ch.name.toLowerCase() === lower) return ch;
        }
        return null;
    }

    // Creates a bin if it doesn't exist; returns the bin item.
    // Each creation is its own small transaction so we hold a live reference.
    async function getOrCreateBin(project, parentItem, name) {
        var existing = await findChildBin(parentItem, name);
        if (existing) return existing;
        var action = parentItem.createBinAction(name, false);
        await project.executeTransaction(function(ca){ ca.addAction(action); }, "AutoSortBins: create bin");
        return await findChildBin(parentItem, name);
    }

    async function backupProject(project) {
        await project.save();
        var projectPath = project.path;
        if (!projectPath) throw new Error("Save the project at least once before backing up.");

        var normalized = projectPath.replace(/\\/g, "/");
        var lastSlash   = normalized.lastIndexOf("/");
        var dirPath     = normalized.substring(0, lastSlash);
        var fileName    = normalized.substring(lastSlash + 1);

        var d=new Date(), p=function(n){return(n<10?"0":"")+n;};
        var ms=d.getMilliseconds(), pm=ms<10?"00":ms<100?"0":"";
        var ts = ""+d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+"_"+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds())+"_"+pm+ms;
        var dot = fileName.lastIndexOf(".");
        var base = dot===-1?fileName:fileName.substring(0,dot), ext = dot===-1?"":fileName.substring(dot);
        var backupName = base + "_autosortbins_backup_" + ts + ext;
        var backupPath = dirPath + "/" + backupName;

        // UXP copyTo silently ignores newName; use fs sync API (callbacks hang in some UXP builds)
        var nodeFs = require('fs');
        try {
            if (typeof nodeFs.copyFileSync === 'function') {
                nodeFs.copyFileSync(projectPath, backupPath);
            } else {
                nodeFs.writeFileSync(backupPath, nodeFs.readFileSync(projectPath));
            }
        } catch(fsErr) {
            throw new Error(fsErr.message || String(fsErr));
        }
        return backupName;
    }

    // ── Sort plan ────────────────────────────────────────────────────────────
    // Returns { moves: [{item, targetBinName, itemName, isBin}], log: [], scanned }
    async function buildSortPlan(rootItem, categories, project, keepSubfolders) {
        var moves = [], log = [], scanned = 0;
        var destNames = {};

        categories.forEach(function(c){ if(c.bin) destNames[c.bin.toLowerCase()] = true; });

        async function isDestBin(item) {
            return isBin(item) && !!destNames[item.name.toLowerCase()];
        }

        // planLoose: find non-bin items under parent that need to move.
        // parentIsRootDest = true means parent is a root-level destination bin,
        // so items already matching parent.name are correctly placed and skipped.
        async function planLoose(parent, parentIsRootDest) {
            var children = await getChildren(parent);
            for (var i=0;i<children.length;i++) {
                var item = children[i];
                if (isBin(item)) continue;
                scanned++;
                var target = await matchCategory(item, categories, project);
                if (!target) continue;
                // Skip only when already in the correctly-placed root-level dest bin
                if (parentIsRootDest && parent.name.toLowerCase()===target.toLowerCase()) continue;
                moves.push({ item: item, targetBinName: target, itemName: item.name, isBin: false });
                log.push(item.name + "  →  " + target);
            }
        }

        // walkFlatten: recurse into ALL bins (including dest bins), so items
        // nested inside misplaced destination bins (e.g. 02 Footage inside 99 Misc)
        // are still found and moved to the correct root-level destination.
        async function walkFlatten(parent, parentIsRootDest) {
            await planLoose(parent, parentIsRootDest);
            var children = await getChildren(parent);
            for (var i=0;i<children.length;i++) {
                var ch = children[i];
                if (!isBin(ch)) continue;
                await walkFlatten(ch, false); // nested bins are never "root-level dest"
            }
        }

        // Keep subfolders: check if a non-dest bin is single-category
        async function singleCategory(bin) {
            var first = null;
            async function walk(parent) {
                var children = await getChildren(parent);
                for (var i=0;i<children.length;i++) {
                    var ch = children[i];
                    if (isBin(ch)) {
                        if (await walk(ch) === "MIXED") return "MIXED";
                    } else {
                        scanned++;
                        var t = await matchCategory(ch, categories, project);
                        if (!t) continue;
                        if (first===null) first=t;
                        else if (first.toLowerCase()!==t.toLowerCase()) return "MIXED";
                    }
                }
                return first;
            }
            var result = await walk(bin);
            return result==="MIXED" ? null : first;
        }

        if (keepSubfolders) {
            // Root-level non-bin items
            await planLoose(rootItem, false);
            var rootChildren = await getChildren(rootItem);
            for (var i=0;i<rootChildren.length;i++) {
                var ch = rootChildren[i];
                if (!isBin(ch)) continue;
                if (await isDestBin(ch)) {
                    // Root-level dest bin: recurse to rescue items nested inside it
                    // that belong elsewhere (e.g. 02 Footage nested in 99 Misc)
                    await walkFlatten(ch, true); // ch IS a root-level dest bin
                } else {
                    // Non-dest root bin: move whole bin if single-category, else flatten
                    var cat = await singleCategory(ch);
                    if (cat) {
                        moves.push({ item: ch, targetBinName: cat, itemName: ch.name, isBin: true });
                        log.push(ch.name + "  →  " + cat + "  (folder)");
                    } else {
                        await walkFlatten(ch, false);
                    }
                }
            }
        } else {
            // Full flatten: items in correctly-placed root-level dest bins are skipped,
            // everything else is re-sorted to root-level destinations
            var rootChildren2 = await getChildren(rootItem);
            for (var j=0;j<rootChildren2.length;j++) {
                var rc = rootChildren2[j];
                if (!isBin(rc)) {
                    scanned++;
                    var t2 = await matchCategory(rc, categories, project);
                    if (t2) { moves.push({ item: rc, targetBinName: t2, itemName: rc.name, isBin: false }); log.push(rc.name+"  →  "+t2); }
                } else {
                    await walkFlatten(rc, await isDestBin(rc));
                }
            }
        }

        return { moves: moves, log: log, scanned: scanned };
    }

    // ── Execute sort (backup → pre-create bins → single transaction) ─────────
    async function executeSort(project, rootItem, plan) {
        // 1. Backup
        var backupName = await backupProject(project);
        appendLog('<span class="ok">✓ Backup saved: ' + esc(backupName) + '</span>');

        // 2. Pre-create all destination bins (each is its own tiny transaction)
        var binCache = {};
        var uniqueTargets = [];
        plan.moves.forEach(function(m){
            var k = m.targetBinName.toLowerCase();
            if (!binCache.hasOwnProperty(k)) { binCache[k] = null; uniqueTargets.push(m.targetBinName); }
        });
        for (var i=0;i<uniqueTargets.length;i++) {
            var binName = uniqueTargets[i];
            var bin = await getOrCreateBin(project, rootItem, binName);
            if (!bin) throw new Error("Could not create bin: " + binName);
            binCache[binName.toLowerCase()] = bin;
        }

        // 3. Pre-build all move actions (needs parent refs; getParentBin is async)
        var actions = [], skipped = [];
        for (var j=0;j<plan.moves.length;j++) {
            var move = plan.moves[j];
            var destBin = binCache[move.targetBinName.toLowerCase()];
            if (!destBin) { skipped.push(move.itemName); continue; }
            try {
                var parent = asFolderItem(await move.item.getParentBin());
                var action = parent.createMoveItemAction(move.item, asFolderItem(destBin));
                actions.push({ action: action, name: move.itemName, target: move.targetBinName });
            } catch(e) {
                skipped.push(move.itemName + " (" + e.message + ")");
            }
        }

        // 4. Execute all moves in a single undoable transaction
        var moved = 0, failLog = [];
        await project.executeTransaction(function(ca) {
            actions.forEach(function(a) {
                try { ca.addAction(a.action); moved++; }
                catch(e) { failLog.push("FAILED: " + a.name); }
            });
        }, "AutoSortBins: Sort");

        skipped.forEach(function(s){ failLog.push("SKIPPED: " + s); });
        return { moved: moved, total: plan.moves.length, failLog: failLog };
    }

    // ── Empty bins ───────────────────────────────────────────────────────────
    async function buildEmptyBinPlan(rootItem) {
        var bins = [], scanned = 0;
        async function walk(bin, depth) {
            scanned++;
            var children = await getChildren(bin);
            var allEmpty = true;
            for (var i=0;i<children.length;i++) {
                var ch = children[i];
                if (isBin(ch)) { var childEmpty = await walk(ch, depth+1); if(!childEmpty) allEmpty=false; }
                else { allEmpty = false; }
            }
            if (allEmpty) bins.push({ item: bin, name: bin.name, depth: depth });
            return allEmpty;
        }
        var rootChildren = await getChildren(rootItem);
        for (var i=0;i<rootChildren.length;i++) {
            if (isBin(rootChildren[i])) await walk(rootChildren[i], 1);
        }
        bins.sort(function(a,b){ return b.depth - a.depth; });
        return { bins: bins, scanned: scanned };
    }

    // True if the bin's subtree contains any non-bin item (an actual clip).
    // A bin that contains only (empty) sub-bins returns false — still removable.
    async function subtreeHasClips(bin) {
        var children = await getChildren(bin);
        for (var i=0;i<children.length;i++) {
            var ch = children[i];
            if (isBin(ch)) { if (await subtreeHasClips(ch)) return true; }
            else { return true; }
        }
        return false;
    }

    async function executeRemoveEmptyBins(project, rootItem, bins) {
        var backupName = await backupProject(project);
        appendCleanupLog('<span class="ok">✓ Backup saved: ' + esc(backupName) + '</span>');

        // Pre-build remove actions; re-verify each bin's subtree still holds no clips.
        // (A parent that contains only empty sub-bins is still removable — we must NOT
        //  reject it just because it has child bins, since actions are built before the
        //  transaction runs and the empty children haven't been removed yet.)
        // Bins are sorted deepest-first, so children are removed before their parents.
        var actions = [], skipped = [];
        for (var i=0;i<bins.length;i++) {
            var rec = bins[i];
            try {
                if (await subtreeHasClips(rec.item)) { skipped.push("no longer empty: " + rec.name); continue; }
                var parent = asFolderItem(await rec.item.getParentBin());
                var action = parent.createRemoveItemAction(rec.item);
                actions.push({ action: action, name: rec.name });
            } catch(e) {
                skipped.push(rec.name + " (" + e.message + ")");
            }
        }

        var removed = 0, failLog = [];
        await project.executeTransaction(function(ca) {
            actions.forEach(function(a){
                try { ca.addAction(a.action); removed++; }
                catch(e) { failLog.push("FAILED: " + a.name); }
            });
        }, "AutoSortBins: Remove Empty Bins");

        skipped.forEach(function(s){ failLog.push("SKIPPED: " + s); });
        return { removed: removed, total: bins.length, failLog: failLog };
    }

    // ── Button handlers ──────────────────────────────────────────────────────
    async function runPreview() {
        if (!ppro) { logError("Premiere Pro API not available."); return; }
        saveState();
        var categories = buildCategories();
        var keepSubfolders = !!($("keepSubfolders") && $("keepSubfolders").checked);

        setStatus("Previewing…", "working");
        try {
            var project = await ppro.Project.getActiveProject();
            if (!project) { logError("No project is open."); return; }
            var rootItem = await project.getRootItem();
            try { _rootGetItemsFn = Object.getPrototypeOf(rootItem).getItems; } catch(e) {}

            var plan = await buildSortPlan(rootItem, categories, project, keepSubfolders);

            if (plan.moves.length === 0) {
                appendLog('<span class="sum"><b>Preview: nothing to move — project is already tidy.</b> <span class="muted">· ' + stamp() + '</span></span>');
                setStatus("Already tidy", "done");
                setSortEnabled(false);
                return;
            }

            appendLog('<span class="sum"><b>Preview: ' + plan.moves.length + ' of ' + plan.scanned + ' items would move</b> <span class="muted">· ' + stamp() + '</span></span>');

            // Group by destination
            var groups = {};
            plan.log.forEach(function(l){
                var idx = l.indexOf("→");
                if (idx===-1) return;
                var dest = l.substring(idx+1).trim();
                groups[dest] = (groups[dest]||0) + 1;
            });
            Object.keys(groups).forEach(function(d){
                var c = groups[d];
                appendLog('<span class="group"><span class="n">'+c+'</span> '+(c===1?"item":"items")+' <span class="arrow">→</span> '+esc(d)+'</span>');
            });
            appendLog('<span class="muted">  Review, then click "Sort Now" to execute. A backup is saved first.</span>');

            lastPreviewPlan = { moves: plan.moves, categories: categories, keepSubfolders: keepSubfolders };
            setSortEnabled(true);
            setStatus("Preview ready", "done");
        } catch(e) {
            logError("Preview failed: " + e.message);
        }
    }

    async function runSort() {
        if (!lastPreviewPlan) { logError("Run Preview first."); return; }
        if (!ppro) { logError("Premiere Pro API not available."); return; }
        saveState();

        var planSnapshot = lastPreviewPlan;
        lastPreviewPlan = null;
        setSortEnabled(false);

        setStatus("Sorting…", "working");
        try {
            var project = await ppro.Project.getActiveProject();
            if (!project) { logError("No project is open."); return; }
            var rootItem = await project.getRootItem();

            var result = await executeSort(project, rootItem, planSnapshot);

            appendLog('<span class="sum"><b>Sorted ' + result.moved + ' item' + (result.moved===1?"":"s") + '.</b> <span class="muted">· ' + stamp() + '</span></span>');
            result.failLog.forEach(function(f){ appendLog('<span class="fail">  ' + esc(f) + '</span>'); });
            setStatus("Sorted " + result.moved, "done");
        } catch(e) {
            logError("Sort failed: " + e.message);
        }
    }

    async function runBackup() {
        if (!ppro) { logError("Premiere Pro API not available."); return; }
        setStatus("Backing up…", "working");
        try {
            var project = await ppro.Project.getActiveProject();
            if (!project) { logError("No project is open."); return; }
            var backupName = await backupProject(project);
            appendLog('<span class="ok">✓ Backup saved: ' + esc(backupName) + ' <span class="muted">· ' + stamp() + '</span></span>');
            setStatus("Backed up", "done");
        } catch(e) {
            logError("Backup failed: " + e.message);
        }
    }

    async function runPreviewEmptyBins() {
        if (!ppro) { appendCleanupLog('<span class="fail">⚠ Premiere Pro API not available.</span>'); return; }
        setStatus("Scanning empty bins…", "working");
        try {
            var project = await ppro.Project.getActiveProject();
            if (!project) { appendCleanupLog('<span class="fail">⚠ No project is open.</span>'); return; }
            var rootItem = await project.getRootItem();
            try { _rootGetItemsFn = Object.getPrototypeOf(rootItem).getItems; } catch(e) {}

            var result = await buildEmptyBinPlan(rootItem);

            if (result.bins.length === 0) {
                appendCleanupLog('<span class="sum"><b>Preview: no empty bins found.</b> <span class="muted">· ' + stamp() + '</span></span>');
                setStatus("No empty bins", "done");
                setEmptyEnabled(false);
                return;
            }

            appendCleanupLog('<span class="sum"><b>Preview: ' + result.bins.length + ' empty bin' + (result.bins.length===1?"":"s") + ' found</b> <span class="muted">· ' + stamp() + '</span></span>');
            result.bins.forEach(function(b){ appendCleanupLog('<span class="bullet">  ' + esc(b.name) + '</span>'); });
            appendCleanupLog('<span class="muted">  Click "Remove previewed" to delete. A backup is saved first.</span>');

            lastEmptyPreviewPlan = result.bins;
            setEmptyEnabled(true);
            setStatus("Empty bin preview ready", "done");
        } catch(e) {
            appendCleanupLog('<span class="fail">⚠ Empty bin preview failed: ' + esc(e.message) + '</span>');
            setStatus("Error", "error");
        }
    }

    async function runRemoveEmptyBins() {
        if (!lastEmptyPreviewPlan || !lastEmptyPreviewPlan.length) { appendCleanupLog('<span class="fail">⚠ Preview empty bins first.</span>'); return; }
        if (!ppro) { appendCleanupLog('<span class="fail">⚠ Premiere Pro API not available.</span>'); return; }

        var count = lastEmptyPreviewPlan.length;
        if (!window.confirm("Remove " + count + " previewed empty bin" + (count===1?"":"s") + "? A backup is saved first.")) {
            appendCleanupLog('<span class="muted">Cancelled.</span>');
            return;
        }

        var snapshot = lastEmptyPreviewPlan;
        lastEmptyPreviewPlan = null;
        setEmptyEnabled(false);
        setStatus("Removing empty bins…", "working");

        try {
            var project = await ppro.Project.getActiveProject();
            if (!project) { appendCleanupLog('<span class="fail">⚠ No project is open.</span>'); return; }
            var rootItem = await project.getRootItem();
            try { _rootGetItemsFn = Object.getPrototypeOf(rootItem).getItems; } catch(e) {}

            var result = await executeRemoveEmptyBins(project, rootItem, snapshot);
            appendCleanupLog('<span class="sum"><b>Removed ' + result.removed + ' empty bin' + (result.removed===1?"":"s") + '.</b> <span class="muted">· ' + stamp() + '</span></span>');
            result.failLog.forEach(function(f){ appendCleanupLog('<span class="fail">  ' + esc(f) + '</span>'); });
            setStatus("Empty bins removed", "done");
        } catch(e) {
            appendCleanupLog('<span class="fail">⚠ Remove empty bins failed: ' + esc(e.message) + '</span>');
            setStatus("Error", "error");
        }
    }

    async function runRemoveAllEmpty() {
        if (!ppro) { appendCleanupLog('<span class="fail">⚠ Premiere Pro API not available.</span>'); return; }
        setStatus("Scanning…", "working");
        try {
            var project = await ppro.Project.getActiveProject();
            if (!project) { appendCleanupLog('<span class="fail">⚠ No project is open.</span>'); return; }
            var rootItem = await project.getRootItem();
            try { _rootGetItemsFn = Object.getPrototypeOf(rootItem).getItems; } catch(e) {}

            var result = await buildEmptyBinPlan(rootItem);
            if (result.bins.length === 0) {
                appendCleanupLog('<span class="sum"><b>No empty bins found.</b> <span class="muted">· ' + stamp() + '</span></span>');
                setStatus("No empty bins", "done");
                return;
            }

            setStatus("Removing " + result.bins.length + " empty bins…", "working");
            var removed = await executeRemoveEmptyBins(project, rootItem, result.bins);
            appendCleanupLog('<span class="sum"><b>Removed ' + removed.removed + ' empty bin' + (removed.removed===1?"":"s") + '.</b> <span class="muted">· ' + stamp() + '</span></span>');
            removed.failLog.forEach(function(f){ appendCleanupLog('<span class="fail">  ' + esc(f) + '</span>'); });
            setStatus("Done", "done");
        } catch(e) {
            appendCleanupLog('<span class="fail">⚠ Remove empty bins failed: ' + esc(e.message) + '</span>');
            setStatus("Error", "error");
        }
    }

    function copyLog() {
        var text = ($("log").innerText||$("log").textContent)||"";
        var done = function(ok){ appendLog('<span class="muted">'+(ok?"Copied.":"Could not copy — select the Activity text and copy manually.")+'</span>'); };
        try {
            if (navigator.clipboard&&navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function(){done(true);},function(){done(false);});
            } else {
                var ta = document.createElement("textarea"); ta.value = text;
                document.body.appendChild(ta); ta.select();
                done(document.execCommand("copy"));
                document.body.removeChild(ta);
            }
        } catch(e) { done(false); }
    }

    // ── Init ─────────────────────────────────────────────────────────────────
    function init() {
        var state = loadState();
        renderRules(state.rules);
        if ($("keepSubfolders")) $("keepSubfolders").checked = !!state.keepSubfolders;

        // Tab switching — use inline style.display (more reliable than class-swap in UXP)
        var tabBtns   = $("tabs").querySelectorAll(".tab");
        var tabPanels = document.querySelectorAll(".tab-panel");

        function showTab(tabName) {
            tabBtns.forEach(function(b) { b.classList.remove("tab--active"); });
            tabPanels.forEach(function(p) { p.style.display = "none"; });
            var panel = $("tab-" + tabName);
            if (panel) {
                panel.style.display = "flex";
                panel.style.flexDirection = "column";
                panel.style.flex = "1";
                panel.style.overflowY = "auto";
                panel.style.minHeight = "0";
            }
            tabBtns.forEach(function(b) {
                if (b.dataset.tab === tabName) b.classList.add("tab--active");
            });
        }

        tabBtns.forEach(function(btn) {
            btn.onclick = function() { showTab(btn.dataset.tab); };
        });

        // Show the initial tab
        showTab("sort");

        $("btnPreview").onclick      = function(){ runPreview(); };
        $("btnSort").onclick         = function(){ runSort(); };
        $("btnBackup").onclick       = function(){ runBackup(); };
        $("btnRemoveAllEmpty").onclick = function(){ runRemoveAllEmpty(); };
        $("btnPreviewEmpty").onclick  = function(){ runPreviewEmptyBins(); };
        $("btnRemoveEmpty").onclick   = function(){ runRemoveEmptyBins(); };
        if ($("copyLog"))  $("copyLog").onclick  = copyLog;
        $("clearLog").onclick = function(){ $("log").innerHTML = ""; };
        if ($("clearLogCleanup")) $("clearLogCleanup").onclick = function(){ $("logCleanup").innerHTML = ""; };

        if ($("keepSubfolders")) {
            $("keepSubfolders").onchange = function(){ saveState(); invalidatePreview(); };
        }

        $("addRule").onclick = function(){
            $("ruleList").appendChild(ruleRow({bin:"",exts:"",keywords:""}));
            invalidatePreview();
        };
        $("resetRules").onclick = function(){
            renderRules(defaultRules()); saveState();
            appendLog('<span class="muted">Rules reset to defaults.</span>');
        };

        setSortEnabled(false);
        setEmptyEnabled(false);

        if (!ppro) {
            appendLog('<span class="fail">⚠ Premiere Pro API unavailable — requires Premiere Pro 22.0+ with UXP support.</span>');
            setStatus("API unavailable", "error");
        } else {
            appendLog('<span class="muted">AutoSortBins v2.11.0 ready. Preview first — Sort saves a backup automatically.</span>');
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
